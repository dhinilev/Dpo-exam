# DPO Office — Setup Guide

An online examination app that runs on Google Apps Script. You enter questions and attendee emails, press **Conduct**, and each attendee receives a personal exam link by email. When they press **Finish**, the server scores their answers and the result appears in your admin page and in the Google Sheet.

Setup takes about 15 minutes on a laptop or desktop (the Apps Script editor does not work well on a phone). After that, everything can be run from your phone.

---

## What you need

- A Google account. Use an **official account** approved by the bank if possible: invitations are sent from this account's email address, and all exam data is stored in its Google Drive.
- The four files in this folder: `Code.gs`, `Admin.html`, `Exam.html`, `Styles.html`.

---

## Step 1 — Create the Sheet

1. Go to **sheets.google.com** and create a blank spreadsheet.
2. Name it, for example, **DPO Office — Exams**.

This Sheet is the app's database. Four tabs (Exams, Questions, Attendees, Submissions) are created automatically.

## Step 2 — Add the code

1. In the Sheet, open **Extensions → Apps Script**.
2. Name the project **DPO Office** (click "Untitled project" at the top).
3. In the file list on the left you will see `Code.gs`. Select all its contents and replace them with the contents of **Code.gs** from this folder.
4. Click **+** next to *Files* → **HTML**, and name it `Admin` (Apps Script adds `.html` itself). Replace its contents with **Admin.html**.
5. Repeat for `Exam` (contents of **Exam.html**) and `Styles` (contents of **Styles.html**).
6. Click the **Save** icon.

The file names must be exactly `Admin`, `Exam` and `Styles`.

## Step 3 — Deploy as a web app

1. Click **Deploy → New deployment**.
2. Click the gear icon next to *Select type* and choose **Web app**.
3. Set:
   - **Description:** DPO Office v1
   - **Execute as:** Me
   - **Who has access:** Anyone
4. Click **Deploy**.
5. Google asks you to authorise. Choose your account. If you see "Google hasn't verified this app", click **Advanced → Go to DPO Office (unsafe)** — this is your own script — and **Allow**.
6. Copy the **Web app URL** (it ends in `/exec`).

"Anyone" lets attendees open their exam link without a Google login. The admin page is protected by the password you set next.

## Step 4 — Set the admin password

1. Go back to the Sheet and **reload** the page.
2. A new menu **DPO Office** appears (it can take a few seconds).
3. Choose **DPO Office → Set or reset admin password** and enter a password of at least 8 characters.
4. Choose **DPO Office → Show app links** to see your admin and exam links.

## Step 5 — Start using it

Open the admin page: your web app URL followed by `?admin`

```
https://script.google.com/macros/s/XXXXXXXX/exec?admin
```

Bookmark it on your phone. Then:

1. **New exam** — title, time allowed, pass mark, and whether attendees see their score at the end.
2. **Questions** — add one at a time, or paste many at once:
   ```
   Q: Who is a Data Principal under the DPDP Act?
   A) The bank
   *B) The individual the data relates to
   C) The Data Protection Board
   D) The DPO

   Q: Which body imposes penalties under the Act?
   A) RBI
   B) CERT-In
   C) Data Protection Board of India
   Answer: C
   ```
3. **Attendees** — add name and email, or paste a list (`Name, email` per line, or two columns from Excel).
4. **Conduct** — press **Conduct exam and send invitations**. Each attendee gets an email with their personal link and access code.
5. **Results** — scores appear as attendees finish, refreshing every 20 seconds. The full record is also in the Sheet's **Submissions** tab.

Before conducting for real, run a test exam with yourself as the only attendee.

---

## How it behaves

| | |
|---|---|
| **Access** | Each attendee has a unique 6-character code built into their link. The code works for one submission only. |
| **Timer** | Starts when the attendee presses Start, and is kept on the server, so closing and reopening the page does not reset it. The exam submits automatically at zero. |
| **Answer key** | Never sent to the attendee's phone. Scoring happens on the server. |
| **Shuffling** | Optional. Each attendee gets their own question and option order. |
| **Late or closed** | Submissions more than 2 minutes after time runs out, or after you close the exam, are accepted but flagged in the Note column. |
| **Resuming** | Answers are kept on the attendee's device while they work, so a dropped connection does not lose them. |
| **Adding people later** | Attendees added while an exam is live are emailed straight away. |
| **Failed emails** | Shown in the Conduct tab with a **Resend** button and a **Copy link** button so you can send the link another way. |

---

## Limits to know

- **Daily email limit:** about **100 recipients/day** on a personal Gmail account, about **1,500/day** on Google Workspace. The admin page shows how many you have left. If the limit is hit, the remaining invitations are marked "Not sent"; resend them the next day or copy their links.
- **Simultaneous use:** Apps Script handles around 30 requests at the same moment. Submissions retry automatically, so a batch of 100–200 attendees is fine. For much larger groups, stagger the exam across batches.
- **Sender address:** invitations come from the Google account that deployed the app.

---

## Updating the app later

If you change any code, **do not create a new deployment** — that gives a new URL and old links stop working. Instead:

**Deploy → Manage deployments → pencil icon → Version: New version → Deploy.** The URL stays the same.

---

## Data protection notes

The app stores attendee names, official email addresses, answers and scores. Under the DPDP Act this is personal data, so:

- Use an account and Drive approved under the bank's IT and information security policy, and record the processing in your register.
- Share the Google Sheet only with people who need the results.
- Agree a retention period and delete old exams from the admin page (this also deletes their attendees and results).
- For bank-wide production use, the same design can be moved to bank-hosted infrastructure; the logic in `Code.gs` maps directly onto a standard web server and database.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| No **DPO Office** menu in the Sheet | Reload the Sheet and wait a few seconds. Check that `Code.gs` was saved. |
| "Script function not found: doGet" | `Code.gs` was not pasted fully, or not saved before deploying. Fix it, then deploy a new version. |
| Admin page says "Set an admin password first" | Use **DPO Office → Set or reset admin password** in the Sheet. |
| "Too many incorrect attempts" | Wait 10 minutes. |
| Attendee sees "access code not found" | Check the code against the Conduct tab. Codes are created only when the exam is conducted. |
| Changes don't appear | Deploy a new version (see *Updating the app later*). |
