/**
 * DPO Office — Online Examination
 * Google Apps Script web app, bound to a Google Sheet.
 *
 * Sheets used (created automatically): Exams, Questions, Attendees, Submissions.
 * Admin page:   <web app URL>?admin
 * Exam page:    <web app URL>?code=ABC123   (each attendee gets their own link by email)
 */

const APP_NAME = 'DPO Office';
const SENDER_NAME = 'DPO Office';
const ORG_LINE = 'Data Protection Office, Karnataka Bank Ltd, Head Office, Mangaluru';
const SESSION_HOURS = 6;
const GRACE_MS = 2 * 60 * 1000;          // late-submission grace after time runs out
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const LETTERS = 'ABCDEF';

const SHEETS = {
  Exams: ['id', 'title', 'durationMin', 'passPct', 'instructions', 'showScore', 'shuffle', 'status', 'createdAt', 'conductedAt'],
  Questions: ['examId', 'qid', 'order', 'text', 'optA', 'optB', 'optC', 'optD', 'optE', 'optF', 'correct'],
  Attendees: ['examId', 'name', 'email', 'code', 'inviteStatus', 'invitedAt', 'startedAt', 'submittedAt'],
  Submissions: ['code', 'examId', 'name', 'email', 'answers', 'startedAt', 'submittedAt', 'timeTakenSec', 'correct', 'total', 'percent', 'result', 'autoSubmitted', 'note']
};

/* ===================== Web entry ===================== */

function doGet(e) {
  const p = (e && e.parameter) || {};
  const isAdmin = Object.prototype.hasOwnProperty.call(p, 'admin');
  const t = HtmlService.createTemplateFromFile(isAdmin ? 'Admin' : 'Exam');
  t.code = String(p.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
  t.appUrl = ScriptApp.getService().getUrl();
  return t.evaluate()
    .setTitle(isAdmin ? APP_NAME + ' — Admin' : APP_NAME + ' — Examination')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.DEFAULT);
}

function include(name) {
  return HtmlService.createHtmlOutputFromFile(name).getContent();
}

/* ===================== Sheet menu ===================== */

function onOpen() {
  SpreadsheetApp.getUi().createMenu('DPO Office')
    .addItem('Set or reset admin password', 'menuSetPassword')
    .addItem('Show app links', 'menuLinks')
    .addToUi();
}

function menuSetPassword() {
  const ui = SpreadsheetApp.getUi();
  const r = ui.prompt('Admin password', 'Choose a password of at least 8 characters for the admin page.', ui.ButtonSet.OK_CANCEL);
  if (r.getSelectedButton() !== ui.Button.OK) return;
  const pw = r.getResponseText();
  if (pw.length < 8) { ui.alert('Use at least 8 characters.'); return; }
  const salt = Utilities.getUuid();
  props_().setProperties({ ADMIN_SALT: salt, ADMIN_HASH: hash_(salt + pw) });
  Object.keys(SHEETS).forEach(sheet_);
  ui.alert('Admin password saved. Existing admin sessions stay signed in until they expire.');
}

function menuLinks() {
  const ui = SpreadsheetApp.getUi();
  const url = ScriptApp.getService().getUrl();
  ui.alert(url
    ? 'Admin page:\n' + url + '?admin\n\nExam page (attendees reach it from their email link):\n' + url
    : 'The web app is not deployed yet. Use Deploy → New deployment → Web app in the Apps Script editor.');
}

/* ===================== Storage helpers ===================== */

function ss_() { return SpreadsheetApp.getActiveSpreadsheet(); }
function props_() { return PropertiesService.getScriptProperties(); }

function sheet_(name) {
  const ss = ss_();
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    const h = SHEETS[name];
    sh.getRange(1, 1, sh.getMaxRows(), h.length).setNumberFormat('@');
    sh.getRange(1, 1, 1, h.length).setValues([h]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

function rows_(name) {
  const sh = sheet_(name);
  const n = sh.getLastRow();
  if (n < 2) return [];
  const h = SHEETS[name];
  return sh.getRange(2, 1, n - 1, h.length).getDisplayValues().map(function (r, i) {
    const o = { _row: i + 2 };
    h.forEach(function (k, j) { o[k] = r[j]; });
    return o;
  });
}

function cell_(v) {
  if (v === null || v === undefined) return '';
  const s = String(v);
  return /^[=+\-@]/.test(s) ? "'" + s : s;   // never let user text become a formula
}

function appendMany_(name, objs) {
  if (!objs.length) return;
  const h = SHEETS[name];
  const sh = sheet_(name);
  const start = sh.getLastRow() + 1;
  if (start + objs.length - 1 > sh.getMaxRows()) sh.insertRowsAfter(sh.getMaxRows(), objs.length + 50);
  const range = sh.getRange(start, 1, objs.length, h.length);
  range.setNumberFormat('@');
  range.setValues(objs.map(function (o) { return h.map(function (k) { return cell_(o[k]); }); }));
}

function update_(name, row, obj) {
  const h = SHEETS[name];
  const sh = sheet_(name);
  const current = sh.getRange(row, 1, 1, h.length).getValues()[0];
  Object.keys(obj).forEach(function (k) {
    const c = h.indexOf(k);
    if (c >= 0) current[c] = cell_(obj[k]);
  });
  sh.getRange(row, 1, 1, h.length).setNumberFormat('@').setValues([current]);
}

function deleteWhere_(name, pred) {
  const sh = sheet_(name);
  rows_(name).filter(pred).map(function (r) { return r._row; })
    .sort(function (a, b) { return b - a; })
    .forEach(function (r) { sh.deleteRow(r); });
}

function withLock_(fn) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(20000)) throw new Error('The server is busy. Please try again in a moment.');
  try { return fn(); } finally { lock.releaseLock(); }
}

const num_ = function (v) { const n = Number(v); return isNaN(n) ? 0 : n; };
const bool_ = function (v) { return v === true || String(v).toUpperCase() === 'TRUE'; };

function examObj_(r) {
  return {
    id: r.id, title: r.title, durationMin: num_(r.durationMin), passPct: num_(r.passPct),
    instructions: r.instructions, showScore: bool_(r.showScore), shuffle: bool_(r.shuffle),
    status: r.status || 'draft', createdAt: num_(r.createdAt), conductedAt: num_(r.conductedAt)
  };
}

function findExam_(id) {
  const r = rows_('Exams').filter(function (x) { return x.id === id; })[0];
  if (!r) throw new Error('Exam not found. It may have been deleted.');
  return r;
}

function questionsFor_(examId) {
  return rows_('Questions').filter(function (q) { return q.examId === examId; })
    .sort(function (a, b) { return num_(a.order) - num_(b.order); })
    .map(function (q) {
      const options = ['optA', 'optB', 'optC', 'optD', 'optE', 'optF'].map(function (k) { return q[k]; }).filter(function (o) { return o !== ''; });
      return { qid: q.qid, text: q.text, options: options, correct: q.correct === '' ? -1 : num_(q.correct) };
    });
}

function newCode_(taken) {
  for (let t = 0; t < 50; t++) {
    let c = '';
    const bytes = Utilities.getUuid().replace(/-/g, '');
    for (let i = 0; i < 6; i++) c += CODE_ALPHABET[parseInt(bytes.substr(i * 2, 2), 16) % CODE_ALPHABET.length];
    if (!taken[c]) { taken[c] = true; return c; }
  }
  throw new Error('Could not create a unique access code.');
}

function fmtTime_(ms) {
  return Utilities.formatDate(new Date(ms), Session.getScriptTimeZone(), 'dd-MMM-yyyy HH:mm');
}

/* ===================== Admin authentication ===================== */

function hash_(s) {
  return Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, s, Utilities.Charset.UTF_8));
}

function adminStatus() {
  return { hasPassword: !!props_().getProperty('ADMIN_HASH') };
}

function login(pw) {
  const p = props_();
  const h = p.getProperty('ADMIN_HASH');
  if (!h) throw new Error('No admin password is set yet. In the Google Sheet, use the menu DPO Office → Set or reset admin password.');
  const cache = CacheService.getScriptCache();
  const fails = num_(cache.get('login_fails'));
  if (fails >= 5) throw new Error('Too many incorrect attempts. Wait 10 minutes and try again.');
  if (hash_(p.getProperty('ADMIN_SALT') + String(pw)) !== h) {
    cache.put('login_fails', String(fails + 1), 600);
    throw new Error('Incorrect password.');
  }
  cache.remove('login_fails');
  const token = Utilities.getUuid() + Utilities.getUuid();
  cache.put('s_' + token, '1', SESSION_HOURS * 3600);
  return token;
}

function logout(token) {
  CacheService.getScriptCache().remove('s_' + token);
  return true;
}

function auth_(token) {
  if (!token || !CacheService.getScriptCache().get('s_' + token)) throw new Error('SESSION_EXPIRED');
}

/* ===================== Admin API ===================== */

function getDashboard(token) {
  auth_(token);
  const att = rows_('Attendees');
  const subs = rows_('Submissions');
  const qs = rows_('Questions');
  const exams = rows_('Exams').map(function (r) {
    const e = examObj_(r);
    e.questionCount = qs.filter(function (q) { return q.examId === e.id; }).length;
    e.attendeeCount = att.filter(function (a) { return a.examId === e.id; }).length;
    e.submittedCount = subs.filter(function (s) { return s.examId === e.id; }).length;
    return e;
  }).sort(function (a, b) { return b.createdAt - a.createdAt; });
  return { exams: exams, appUrl: ScriptApp.getService().getUrl(), sheetUrl: ss_().getUrl(), emailQuota: MailApp.getRemainingDailyQuota() };
}

function getExam(token, examId) {
  auth_(token);
  const exam = examObj_(findExam_(examId));
  const subs = rows_('Submissions').filter(function (s) { return s.examId === examId; });
  const attendees = rows_('Attendees').filter(function (a) { return a.examId === examId; }).map(function (a) {
    const s = subs.filter(function (x) { return x.code === a.code && a.code; })[0];
    return {
      name: a.name, email: a.email, code: a.code, inviteStatus: a.inviteStatus, invitedAt: a.invitedAt,
      started: !!a.startedAt, result: s ? {
        correct: num_(s.correct), total: num_(s.total), percent: num_(s.percent), result: s.result,
        submittedAt: s.submittedAt, timeTakenSec: num_(s.timeTakenSec), auto: bool_(s.autoSubmitted), note: s.note
      } : null
    };
  });
  return { exam: exam, questions: questionsFor_(examId), attendees: attendees, appUrl: ScriptApp.getService().getUrl(), emailQuota: MailApp.getRemainingDailyQuota() };
}

function saveExam(token, data) {
  auth_(token);
  const title = String(data.title || '').trim();
  if (!title) throw new Error('Enter an exam title.');
  const dur = Math.round(num_(data.durationMin));
  if (dur < 1 || dur > 300) throw new Error('Time allowed must be between 1 and 300 minutes.');
  const pass = Math.round(num_(data.passPct));
  if (pass < 0 || pass > 100) throw new Error('Pass mark must be between 0 and 100.');
  const body = {
    title: title.slice(0, 150), durationMin: dur, passPct: pass,
    instructions: String(data.instructions || '').trim().slice(0, 1500),
    showScore: data.showScore ? 'TRUE' : 'FALSE', shuffle: data.shuffle ? 'TRUE' : 'FALSE'
  };
  return withLock_(function () {
    if (data.id) {
      const r = findExam_(data.id);
      update_('Exams', r._row, body);
      return data.id;
    }
    const id = 'EX' + Date.now().toString(36).toUpperCase();
    body.id = id; body.status = 'draft'; body.createdAt = Date.now(); body.conductedAt = '';
    appendMany_('Exams', [body]);
    return id;
  });
}

function deleteExam(token, examId) {
  auth_(token);
  return withLock_(function () {
    findExam_(examId);
    ['Submissions', 'Attendees', 'Questions'].forEach(function (n) {
      deleteWhere_(n, function (r) { return r.examId === examId; });
    });
    deleteWhere_('Exams', function (r) { return r.id === examId; });
    return true;
  });
}

function saveQuestions(token, examId, list) {
  auth_(token);
  return withLock_(function () {
    const exam = examObj_(findExam_(examId));
    if (exam.status !== 'draft') throw new Error('Questions are locked once an exam is conducted.');
    if (!Array.isArray(list) || list.length > 300) throw new Error('An exam can have up to 300 questions.');
    const clean = list.map(function (q, i) {
      const text = String(q.text || '').trim();
      const opts = (q.options || []).map(function (o) { return String(o || '').trim(); }).filter(Boolean).slice(0, 6);
      const correct = Math.round(num_(q.correct));
      if (!text) throw new Error('Question ' + (i + 1) + ' has no text.');
      if (opts.length < 2) throw new Error('Question ' + (i + 1) + ' needs at least two options.');
      if (correct < 0 || correct >= opts.length) throw new Error('Question ' + (i + 1) + ' has no correct answer selected.');
      const row = { examId: examId, qid: q.qid || ('Q' + Utilities.getUuid().slice(0, 8)), order: i + 1, text: text.slice(0, 1000), correct: correct };
      ['optA', 'optB', 'optC', 'optD', 'optE', 'optF'].forEach(function (k, j) { row[k] = opts[j] ? opts[j].slice(0, 500) : ''; });
      return row;
    });
    deleteWhere_('Questions', function (r) { return r.examId === examId; });
    appendMany_('Questions', clean);
    return questionsFor_(examId);
  });
}

function addAttendees(token, examId, rows) {
  auth_(token);
  const res = withLock_(function () {
    const exam = examObj_(findExam_(examId));
    const all = rows_('Attendees');
    const existing = {};
    const taken = {};
    all.forEach(function (a) { if (a.code) taken[a.code] = true; if (a.examId === examId) existing[a.email.toLowerCase()] = true; });
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const add = [];
    let skipped = 0;
    (rows || []).forEach(function (r) {
      const email = String(r.email || '').trim().toLowerCase();
      if (!re.test(email) || existing[email]) { skipped++; return; }
      existing[email] = true;
      add.push({
        examId: examId, name: String(r.name || '').trim().slice(0, 100), email: email,
        code: exam.status === 'draft' ? '' : newCode_(taken), inviteStatus: exam.status === 'draft' ? '' : 'Pending',
        invitedAt: '', startedAt: '', submittedAt: ''
      });
    });
    if (add.length > 500) throw new Error('Add up to 500 attendees at a time.');
    appendMany_('Attendees', add);
    return { added: add.length, skipped: skipped, live: exam.status === 'live', emails: add.map(function (a) { return a.email; }) };
  });
  let sent = null;
  if (res.live && res.added) sent = sendInvites_(examId, res.emails);
  return { added: res.added, skipped: res.skipped, sent: sent };
}

function removeAttendee(token, examId, email) {
  auth_(token);
  return withLock_(function () {
    const subs = rows_('Submissions').filter(function (s) { return s.examId === examId && s.email === email; });
    if (subs.length) throw new Error('This attendee has already submitted, so they cannot be removed.');
    deleteWhere_('Attendees', function (a) { return a.examId === examId && a.email === email; });
    return true;
  });
}

function conductExam(token, examId) {
  auth_(token);
  withLock_(function () {
    const exam = examObj_(findExam_(examId));
    if (exam.status !== 'draft') throw new Error('This exam has already been conducted.');
    const qs = questionsFor_(examId);
    if (!qs.length) throw new Error('Add at least one question first.');
    if (qs.some(function (q) { return q.correct < 0; })) throw new Error('Every question needs a correct answer.');
    const all = rows_('Attendees');
    const mine = all.filter(function (a) { return a.examId === examId; });
    if (!mine.length) throw new Error('Add at least one attendee first.');
    const taken = {};
    all.forEach(function (a) { if (a.code) taken[a.code] = true; });
    mine.forEach(function (a) {
      update_('Attendees', a._row, { code: a.code || newCode_(taken), inviteStatus: 'Pending' });
    });
    update_('Exams', findExam_(examId)._row, { status: 'live', conductedAt: Date.now() });
  });
  return sendInvites_(examId, null);
}

function resendInvite(token, examId, email) {
  auth_(token);
  const exam = examObj_(findExam_(examId));
  if (exam.status !== 'live') throw new Error('Invitations can only be sent while the exam is live.');
  return sendInvites_(examId, [email], true);
}

function setStatus(token, examId, status) {
  auth_(token);
  if (['live', 'closed'].indexOf(status) < 0) throw new Error('Unknown status.');
  return withLock_(function () {
    const r = findExam_(examId);
    if (r.status === 'draft') throw new Error('Conduct the exam first.');
    update_('Exams', r._row, { status: status });
    return status;
  });
}

/* ===================== Email ===================== */

function sendInvites_(examId, emails, force) {
  const exam = examObj_(findExam_(examId));
  const qCount = questionsFor_(examId).length;
  const url = ScriptApp.getService().getUrl();
  if (!url) throw new Error('Deploy the web app before sending invitations.');
  const targets = rows_('Attendees').filter(function (a) {
    if (a.examId !== examId || !a.code) return false;
    if (emails) return emails.indexOf(a.email) >= 0;
    return a.inviteStatus !== 'Sent';
  });
  let sent = 0;
  const failed = [];
  targets.forEach(function (a) {
    if (!force && a.inviteStatus === 'Sent') return;
    if (MailApp.getRemainingDailyQuota() < 1) {
      update_('Attendees', a._row, { inviteStatus: 'Not sent: daily email limit reached' });
      failed.push({ email: a.email, reason: 'Daily email limit reached' });
      return;
    }
    try {
      const link = url + '?code=' + a.code;
      MailApp.sendEmail({
        to: a.email,
        subject: exam.title + ' — online exam from the DPO Office',
        name: SENDER_NAME,
        body: inviteText_(exam, a, link, qCount),
        htmlBody: inviteHtml_(exam, a, link, qCount)
      });
      update_('Attendees', a._row, { inviteStatus: 'Sent', invitedAt: fmtTime_(Date.now()) });
      sent++;
    } catch (err) {
      update_('Attendees', a._row, { inviteStatus: 'Failed: ' + String(err.message || err).slice(0, 120) });
      failed.push({ email: a.email, reason: String(err.message || err) });
    }
  });
  return { sent: sent, failed: failed, quotaLeft: MailApp.getRemainingDailyQuota() };
}

function inviteText_(exam, a, link, n) {
  return 'Dear ' + (a.name || 'Colleague') + ',\n\n' +
    'You are invited to take "' + exam.title + '", conducted by the Data Protection Office.\n\n' +
    'Open your exam: ' + link + '\n' +
    'Your access code: ' + a.code + '\n\n' +
    'Questions: ' + n + '   Time allowed: ' + exam.durationMin + ' minutes\n\n' +
    'Press Start when you are ready. Your answers are scored automatically when you press Finish. ' +
    'This link is personal to you and works once.\n\n' + ORG_LINE;
}

function inviteHtml_(exam, a, link, n) {
  const e = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  return '<div style="font-family:Arial,Helvetica,sans-serif;color:#16212b;max-width:560px;line-height:1.5">' +
    '<p style="font-size:12px;letter-spacing:1px;text-transform:uppercase;color:#5a6773;margin:0 0 4px">Data Protection Office</p>' +
    '<h2 style="margin:0 0 16px;font-family:Georgia,serif;font-weight:600">' + e(exam.title) + '</h2>' +
    '<p>Dear ' + e(a.name || 'Colleague') + ',</p>' +
    '<p>You are invited to take this exam, conducted by the Data Protection Office.</p>' +
    '<table style="border-collapse:collapse;margin:12px 0"><tr><td style="padding:4px 16px 4px 0;color:#5a6773">Questions</td><td><b>' + n + '</b></td></tr>' +
    '<tr><td style="padding:4px 16px 4px 0;color:#5a6773">Time allowed</td><td><b>' + exam.durationMin + ' minutes</b></td></tr>' +
    '<tr><td style="padding:4px 16px 4px 0;color:#5a6773">Access code</td><td><b style="font-family:monospace;font-size:16px;letter-spacing:2px">' + e(a.code) + '</b></td></tr></table>' +
    '<p style="margin:20px 0"><a href="' + e(link) + '" style="background:#0d5466;color:#ffffff;text-decoration:none;padding:12px 22px;border-radius:6px;font-weight:bold;display:inline-block">Open my exam</a></p>' +
    '<p style="font-size:13px;color:#5a6773">Press Start when you are ready. Your answers are scored automatically when you press Finish. This link is personal to you and works once. If the button does not work, copy this address into your browser:<br>' + e(link) + '</p>' +
    '<p style="font-size:13px;color:#5a6773;border-top:1px solid #d3dae1;padding-top:12px;margin-top:20px">' + e(ORG_LINE) + '</p></div>';
}

/* ===================== Attendee API ===================== */

function attendee_(code) {
  code = String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (code.length !== 6) return null;
  return rows_('Attendees').filter(function (a) { return a.code === code; })[0] || null;
}

function checkCode(code) {
  const a = attendee_(code);
  if (!a) return { ok: false, message: 'That access code was not found. Check it against your invitation email.' };
  const exam = examObj_(findExam_(a.examId));
  const info = { title: exam.title, durationMin: exam.durationMin, questionCount: questionsFor_(exam.id).length, instructions: exam.instructions, name: a.name };
  if (a.submittedAt) return { ok: true, state: 'done', exam: info };
  if (exam.status === 'closed') return { ok: true, state: 'closed', exam: info };
  if (exam.status !== 'live') return { ok: true, state: 'notlive', exam: info };
  return { ok: true, state: a.startedAt ? 'inprogress' : 'ready', exam: info };
}

function seeded_(seed) {
  let h = 1779033703 ^ seed.length;
  for (let i = 0; i < seed.length; i++) { h = Math.imul(h ^ seed.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
  return function () {
    h = Math.imul(h ^ (h >>> 16), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909);
    return ((h ^= h >>> 16) >>> 0) / 4294967296;
  };
}

function shuffle_(arr, seed) {
  const r = seeded_(seed);
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; }
  return a;
}

function startExam(code) {
  return withLock_(function () {
    const a = attendee_(code);
    if (!a) throw new Error('That access code was not found.');
    if (a.submittedAt) throw new Error('You have already submitted this exam.');
    const exam = examObj_(findExam_(a.examId));
    if (exam.status !== 'live') throw new Error(exam.status === 'closed' ? 'This exam has closed.' : 'This exam has not started yet.');
    let startedAt = num_(a.startedAt);
    if (!startedAt) { startedAt = Date.now(); update_('Attendees', a._row, { startedAt: startedAt }); }
    let qs = questionsFor_(exam.id).map(function (q) {
      let opts = q.options.map(function (t, i) { return { i: i, text: t }; });
      if (exam.shuffle) opts = shuffle_(opts, a.code + q.qid);
      return { qid: q.qid, text: q.text, options: opts };   // correct answer is never sent
    });
    if (exam.shuffle) qs = shuffle_(qs, a.code);
    return { title: exam.title, durationMin: exam.durationMin, startedAt: startedAt, serverNow: Date.now(), questions: qs };
  });
}

function scoreAnswers_(questions, answers) {
  let correct = 0;
  const clean = {};
  questions.forEach(function (q) {
    const v = answers ? answers[q.qid] : undefined;
    if (v === undefined || v === null || v === '') return;
    const n = Math.round(Number(v));
    if (isNaN(n) || n < 0 || n >= q.options.length) return;
    clean[q.qid] = n;
    if (n === q.correct) correct++;
  });
  const total = questions.length;
  return { correct: correct, total: total, percent: total ? Math.round(correct * 1000 / total) / 10 : 0, answers: clean };
}

function submitExam(code, answers, auto) {
  return withLock_(function () {
    const a = attendee_(code);
    if (!a) throw new Error('That access code was not found.');
    const exam = examObj_(findExam_(a.examId));
    const existing = rows_('Submissions').filter(function (s) { return s.code === a.code; })[0];
    if (existing) return outcome_(exam, num_(existing.correct), num_(existing.total), num_(existing.percent), existing.result);
    if (exam.status === 'draft') throw new Error('This exam has not started yet.');
    const now = Date.now();
    const startedAt = num_(a.startedAt) || now;
    const limit = startedAt + exam.durationMin * 60000;
    const notes = [];
    if (now > limit + GRACE_MS) notes.push('Submitted ' + Math.round((now - limit) / 60000) + ' min after time ran out');
    if (exam.status === 'closed') notes.push('Submitted after the exam was closed');
    const sc = scoreAnswers_(questionsFor_(exam.id), answers || {});
    const result = sc.percent >= exam.passPct ? 'Pass' : 'Not passed';
    appendMany_('Submissions', [{
      code: a.code, examId: exam.id, name: a.name, email: a.email, answers: JSON.stringify(sc.answers),
      startedAt: fmtTime_(startedAt), submittedAt: fmtTime_(now), timeTakenSec: Math.round((now - startedAt) / 1000),
      correct: sc.correct, total: sc.total, percent: sc.percent, result: result, autoSubmitted: auto ? 'TRUE' : 'FALSE', note: notes.join('; ')
    }]);
    update_('Attendees', a._row, { submittedAt: fmtTime_(now) });
    return outcome_(exam, sc.correct, sc.total, sc.percent, result);
  });
}

function outcome_(exam, correct, total, percent, result) {
  const o = { submitted: true, title: exam.title, showScore: exam.showScore };
  if (exam.showScore) { o.correct = correct; o.total = total; o.percent = percent; o.result = result; }
  return o;
}
